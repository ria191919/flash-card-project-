package me.anu.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class FlashcardEditActivity extends AppCompatActivity {

    private EditText questionEditText;
    private EditText answerEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcard_edit);

        questionEditText = findViewById(R.id.questionEditText);
        answerEditText = findViewById(R.id.answerEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(v -> {
            String question = questionEditText.getText().toString().trim();
            String answer = answerEditText.getText().toString().trim();

            if (!question.isEmpty() && !answer.isEmpty()) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("QUESTION", question);
                resultIntent.putExtra("ANSWER", answer);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}


/*
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class FlashcardEditActivity extends AppCompatActivity {

    private EditText questionEditText;
    private EditText answerEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcard_edit);

        questionEditText = findViewById(R.id.questionEditText);
        answerEditText = findViewById(R.id.answerEditText);
        saveButton = findViewById(R.id.saveButton);

        // Check if opened for editing
        Intent intent = getIntent();
        if (intent.hasExtra("question") && intent.hasExtra("answer")) {
            questionEditText.setText(intent.getStringExtra("question"));
            answerEditText.setText(intent.getStringExtra("answer"));
        }

        saveButton.setOnClickListener(v -> {
            String question = questionEditText.getText().toString().trim();
            String answer = answerEditText.getText().toString().trim();

            if (!question.isEmpty() && !answer.isEmpty()) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("QUESTION", question);
                resultIntent.putExtra("ANSWER", answer);
                resultIntent.putExtra("position", intent.getIntExtra("position", -1));
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}

*/