package me.anu.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Collections;
import java.util.List;

public class FlashcardViewActivity extends AppCompatActivity {

    private TextView flashcardTextView;
    private Button flipButton, shuffleButton, markAsKnownButton;
    private List<Flashcard> flashcardList;
    private int currentFlashcardIndex = 0;
    private boolean showingQuestion = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcard_view);

        flashcardTextView = findViewById(R.id.flashcardTextView);
        flipButton = findViewById(R.id.flipButton);
        shuffleButton = findViewById(R.id.shuffleButton);
        markAsKnownButton = findViewById(R.id.markAsKnownButton);

        // Retrieve flashcard list from MainActivity
        flashcardList = (List<Flashcard>) getIntent().getSerializableExtra("flashcardList");

        // Check if flashcard list is empty or null, and display message if so
        if (flashcardList == null || flashcardList.isEmpty()) {
            flashcardTextView.setText("No flashcards available.");
            flipButton.setEnabled(false);
            shuffleButton.setEnabled(false);
            markAsKnownButton.setEnabled(false);
            return;
        }

        // Display the first flashcard
        showFlashcard();

        // Flip between question and answer
        flipButton.setOnClickListener(v -> {
            showingQuestion = !showingQuestion;
            showFlashcard();
        });

        // Shuffle flashcards
        shuffleButton.setOnClickListener(v -> {
            Collections.shuffle(flashcardList);
            currentFlashcardIndex = 0;
            showFlashcard();
        });

        // Mark flashcard as known
        markAsKnownButton.setOnClickListener(v -> markAsKnownButton.setText("Known"));
    }

    private void showFlashcard() {
        Flashcard currentFlashcard = flashcardList.get(currentFlashcardIndex);
        flashcardTextView.setText(showingQuestion ? currentFlashcard.getQuestion() : currentFlashcard.getAnswer());
    }
}



/*
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Collections;
import java.util.List;

public class FlashcardViewActivity extends AppCompatActivity {

    private TextView flashcardTextView;
    private Button flipButton, shuffleButton, markAsKnownButton;
    private List<Flashcard> flashcardList;
    private int currentFlashcardIndex = 0;
    private boolean showingQuestion = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcard_view);

        flashcardTextView = findViewById(R.id.flashcardTextView);
        flipButton = findViewById(R.id.flipButton);
        shuffleButton = findViewById(R.id.shuffleButton);
        markAsKnownButton = findViewById(R.id.markAsKnownButton);

        // Retrieve flashcard list from MainActivity
        flashcardList = (List<Flashcard>) getIntent().getSerializableExtra("flashcardList");

        // Display the first flashcard
        showFlashcard();

        // Flip between question and answer
        flipButton.setOnClickListener(v -> {
            showingQuestion = !showingQuestion;
            showFlashcard();
        });

        // Shuffle flashcards
        shuffleButton.setOnClickListener(v -> {
            Collections.shuffle(flashcardList);
            currentFlashcardIndex = 0;
            showFlashcard();
        });

        // Mark flashcard as known
        markAsKnownButton.setOnClickListener(v -> {
            markFlashcardAsKnown();
        });
    }

    private void showFlashcard() {
        Flashcard currentFlashcard = flashcardList.get(currentFlashcardIndex);
        if (showingQuestion) {
            flashcardTextView.setText(currentFlashcard.getQuestion());
        } else {
            flashcardTextView.setText(currentFlashcard.getAnswer());
        }
    }

    private void markFlashcardAsKnown() {
        // For example, show a message that it’s marked as known
        markAsKnownButton.setText("Known");
    }
}
*/