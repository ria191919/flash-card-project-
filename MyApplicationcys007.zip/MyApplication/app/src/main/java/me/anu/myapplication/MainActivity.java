package me.anu.myapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView flashcardRecyclerView;
    private FlashcardAdapter flashcardAdapter;
    private List<Flashcard> flashcardList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        flashcardRecyclerView = findViewById(R.id.flashcardRecyclerView);
        flashcardRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        flashcardList = new ArrayList<>();
        flashcardAdapter = new FlashcardAdapter(this, flashcardList);
        flashcardRecyclerView.setAdapter(flashcardAdapter);

        FloatingActionButton addFlashcardFab = findViewById(R.id.addFlashcardFab);
        addFlashcardFab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FlashcardEditActivity.class);
            startActivityForResult(intent, 1);
        });

        FloatingActionButton viewFlashcardsFab = findViewById(R.id.viewFlashcardsFab);
        viewFlashcardsFab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FlashcardViewActivity.class);
            intent.putExtra("flashcardList", (Serializable) flashcardList); // Cast to Serializable
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            String question = data.getStringExtra("QUESTION");
            String answer = data.getStringExtra("ANSWER");
            flashcardList.add(new Flashcard(question, answer));
            flashcardAdapter.notifyDataSetChanged();
        } else if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            int position = data.getIntExtra("position", -1);
            String editedQuestion = data.getStringExtra("QUESTION");
            String editedAnswer = data.getStringExtra("ANSWER");

            if (position != -1) {
                Flashcard updatedFlashcard = new Flashcard(editedQuestion, editedAnswer);
                flashcardList.set(position, updatedFlashcard);
                flashcardAdapter.notifyItemChanged(position);
            }
        }
    }
}


/*
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView flashcardRecyclerView;
    private FlashcardAdapter flashcardAdapter;
    private List<Flashcard> flashcardList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge display
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize RecyclerView
        flashcardRecyclerView = findViewById(R.id.flashcardRecyclerView);
        flashcardRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize flashcard list and adapter
        flashcardList = new ArrayList<>();
        flashcardAdapter = new FlashcardAdapter(this, flashcardList); // Pass 'this' as the Context
        flashcardRecyclerView.setAdapter(flashcardAdapter);

        // Floating Action Button to add new flashcards
        FloatingActionButton addFlashcardFab = findViewById(R.id.addFlashcardFab);
        addFlashcardFab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FlashcardEditActivity.class);
            startActivityForResult(intent, 1); // Request code 1 for adding flashcard
        });

        // Button or action to view flashcard list in FlashcardViewActivity
        FloatingActionButton viewFlashcardsFab = findViewById(R.id.viewFlashcardsFab);
        viewFlashcardsFab.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FlashcardViewActivity.class);
            intent.putExtra("flashcardList", (Serializable) flashcardList);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Adding new flashcard
            String question = data.getStringExtra("QUESTION");
            String answer = data.getStringExtra("ANSWER");

            flashcardList.add(new Flashcard(question, answer));
            flashcardAdapter.notifyDataSetChanged();
        } else if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            // Editing existing flashcard
            int position = data.getIntExtra("position", -1);
            String editedQuestion = data.getStringExtra("QUESTION");
            String editedAnswer = data.getStringExtra("ANSWER");

            if (position != -1) {
                Flashcard updatedFlashcard = new Flashcard(editedQuestion, editedAnswer);
                flashcardList.set(position, updatedFlashcard);
                flashcardAdapter.notifyItemChanged(position);
            }
        }
    }
}
*/
